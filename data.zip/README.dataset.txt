# vegetables Detection > 2023-12-16 9:01pm
https://universe.roboflow.com/pratik1/vegetables-detection-wmpu4

Provided by a Roboflow user
License: MIT

